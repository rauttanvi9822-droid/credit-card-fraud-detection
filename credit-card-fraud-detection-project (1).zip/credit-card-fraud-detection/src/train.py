from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    ConfusionMatrixDisplay,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src.data_utils import BASE_FEATURES, TARGET, load_dataset

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "raw" / "creditcard.csv"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
RANDOM_STATE = 42


def build_preprocessor() -> ColumnTransformer:
    # V1-V28 are already anonymized/PCA-transformed in the source dataset.
    # Scale only Time and Amount. This transformer is fitted inside each model
    # pipeline, using training data only.
    return ColumnTransformer(
        transformers=[("scale_time_amount", StandardScaler(), ["Time", "Amount"])],
        remainder="passthrough",
        verbose_feature_names_out=False,
    )


def main() -> None:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    df = load_dataset(DATA_PATH)
    X = df[BASE_FEATURES]
    y = df[TARGET]

    print("\n=== Dataset overview ===")
    print(f"Rows: {len(df):,}")
    print(f"Legitimate (0): {(y == 0).sum():,}")
    print(f"Fraud (1): {(y == 1).sum():,}")
    print(f"Fraud percentage: {y.mean() * 100:.4f}%")
    print("Note: high accuracy alone is not a useful fraud metric.")

    # Split before any fitting: 70% train, 15% validation, 15% final test.
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=RANDOM_STATE
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, stratify=y_temp, random_state=RANDOM_STATE
    )

    candidates = {
        "Logistic Regression": LogisticRegression(
            class_weight="balanced",
            max_iter=2000,
            solver="liblinear",
            random_state=RANDOM_STATE,
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=150,
            class_weight="balanced_subsample",
            min_samples_leaf=2,
            n_jobs=-1,
            random_state=RANDOM_STATE,
        ),
    }

    fitted_models = {}
    validation_scores = {}

    print("\n=== Train models and compare on validation set ===")
    for name, estimator in candidates.items():
        pipeline = Pipeline(
            steps=[
                ("preprocess", build_preprocessor()),
                ("model", estimator),
            ]
        )
        print(f"\nTraining {name}...")
        pipeline.fit(X_train, y_train)
        val_probabilities = pipeline.predict_proba(X_val)[:, 1]
        val_ap = average_precision_score(y_val, val_probabilities)
        fitted_models[name] = pipeline
        validation_scores[name] = float(val_ap)
        print(f"{name} validation Average Precision (PR-AUC summary): {val_ap:.4f}")

    # Select using validation data only; test data did not influence selection.
    best_name = max(validation_scores, key=validation_scores.get)
    best_model = fitted_models[best_name]
    print(f"\nSelected model based on validation Average Precision: {best_name}")

    # Evaluate the selected model once on the untouched test split.
    test_probabilities = best_model.predict_proba(X_test)[:, 1]
    threshold = 0.50
    test_predictions = (test_probabilities >= threshold).astype(int)

    metrics = {
        "selected_model": best_name,
        "selection_metric": "validation_average_precision",
        "validation_average_precision": validation_scores,
        "test_threshold": threshold,
        "test_precision": float(precision_score(y_test, test_predictions, zero_division=0)),
        "test_recall": float(recall_score(y_test, test_predictions, zero_division=0)),
        "test_f1": float(f1_score(y_test, test_predictions, zero_division=0)),
        "test_average_precision_pr_auc_summary": float(
            average_precision_score(y_test, test_probabilities)
        ),
        "test_roc_auc": float(roc_auc_score(y_test, test_probabilities)),
        "test_rows": int(len(y_test)),
        "test_fraud_rows": int((y_test == 1).sum()),
        "test_legitimate_rows": int((y_test == 0).sum()),
        "note": (
            "These are results from this run. Average Precision summarizes the "
            "precision-recall curve and is commonly reported as PR-AUC-style metric."
        ),
    }

    print("\n=== Final test results (selected model, threshold 0.50) ===")
    print(f"Precision: {metrics['test_precision']:.4f}")
    print(f"Recall:    {metrics['test_recall']:.4f}")
    print(f"F1-score:  {metrics['test_f1']:.4f}")
    print(f"PR-AUC / Average Precision: {metrics['test_average_precision_pr_auc_summary']:.4f}")
    print(f"ROC-AUC:   {metrics['test_roc_auc']:.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, test_predictions, target_names=["Legitimate", "Fraud"], zero_division=0))

    joblib.dump(
        {
            "pipeline": best_model,
            "feature_columns": BASE_FEATURES,
            "target_column": TARGET,
            "threshold": threshold,
            "selected_model": best_name,
        },
        MODEL_DIR / "fraud_model.joblib",
    )

    with (REPORT_DIR / "test_metrics.json").open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay.from_predictions(
        y_test,
        test_predictions,
        display_labels=["Legitimate", "Fraud"],
        cmap="Blues",
        ax=ax,
        colorbar=False,
    )
    ax.set_title(f"Test Confusion Matrix — {best_name}")
    fig.tight_layout()
    fig.savefig(REPORT_DIR / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    print("\nSaved:")
    print(f"- {MODEL_DIR / 'fraud_model.joblib'}")
    print(f"- {REPORT_DIR / 'test_metrics.json'}")
    print(f"- {REPORT_DIR / 'confusion_matrix.png'}")
    print("\nTraining complete. Use only these actual results in your portfolio.")


if __name__ == "__main__":
    main()
