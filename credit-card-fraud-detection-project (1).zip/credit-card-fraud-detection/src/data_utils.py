from pathlib import Path

import pandas as pd

TARGET = "Class"
BASE_FEATURES = ["Time"] + [f"V{i}" for i in range(1, 29)] + ["Amount"]


def load_dataset(path: str | Path) -> pd.DataFrame:
    """Load and validate the Kaggle dataset."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at: {path}\n"
            "Download creditcard.csv from Kaggle and place it in data/raw/creditcard.csv."
        )

    df = pd.read_csv(path)
    required = set(BASE_FEATURES + [TARGET])
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    df = df[BASE_FEATURES + [TARGET]].copy()
    df = df.dropna(subset=BASE_FEATURES + [TARGET])
    df[TARGET] = df[TARGET].astype(int)

    if not set(df[TARGET].unique()).issubset({0, 1}):
        raise ValueError("Class must contain only 0 (legitimate) and 1 (fraud).")
    if df[TARGET].nunique() != 2:
        raise ValueError("The dataset must contain both Class 0 and Class 1 rows.")

    return df
