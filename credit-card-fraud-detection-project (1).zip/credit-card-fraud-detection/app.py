from pathlib import Path

import joblib
import pandas as pd
import streamlit as st
from sklearn.metrics import average_precision_score, f1_score, precision_score, recall_score, confusion_matrix

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "fraud_model.joblib"
EXPECTED_FEATURES = ["Time"] + [f"V{i}" for i in range(1, 29)] + ["Amount"]

st.set_page_config(page_title="Credit Card Fraud Detection", page_icon="💳", layout="wide")

st.title("💳 Credit Card Fraud Detection")
st.caption("Educational ML demo using an anonymized public dataset. Not for real financial decisions.")

if not MODEL_PATH.exists():
    st.warning("The trained model is not available yet.")
    st.code("python -m src.train", language="powershell")
    st.info("First download the Kaggle dataset to data/raw/creditcard.csv, then run the training command.")
    st.stop()

bundle = joblib.load(MODEL_PATH)
model = bundle["pipeline"]
threshold_default = float(bundle.get("threshold", 0.5))
selected_model = bundle.get("selected_model", "Trained model")

with st.sidebar:
    st.header("Settings")
    st.write(f"**Loaded model:** {selected_model}")
    threshold = st.slider(
        "Fraud probability threshold",
        min_value=0.05,
        max_value=0.95,
        value=threshold_default,
        step=0.05,
        help="Lower thresholds usually catch more fraud but may create more false alarms.",
    )
    st.caption("Changing this threshold changes labels, not the trained model.")

st.subheader("Score transactions from a CSV")
st.write(
    "Upload a CSV with `Time`, `V1`–`V28`, and `Amount`. "
    "The optional `Class` column is used only for evaluation display and is never sent to the model."
)
uploaded = st.file_uploader("Choose a transaction CSV", type=["csv"])

if uploaded is not None:
    try:
        data = pd.read_csv(uploaded)
        missing = sorted(set(EXPECTED_FEATURES) - set(data.columns))
        if missing:
            st.error("Missing required feature columns: " + ", ".join(missing))
            st.stop()

        X = data[EXPECTED_FEATURES].copy()
        if X.isna().any().any():
            st.error("The uploaded file contains missing values in the required feature columns. Please clean them first.")
            st.stop()
        if not all(pd.api.types.is_numeric_dtype(X[col]) for col in EXPECTED_FEATURES):
            st.error("All feature columns must be numeric.")
            st.stop()

        probabilities = model.predict_proba(X)[:, 1]
        predictions = (probabilities >= threshold).astype(int)

        results = data.copy()
        results["fraud_probability_percent"] = (probabilities * 100).round(2)
        results["predicted_class"] = predictions
        results["predicted_label"] = results["predicted_class"].map(
            {0: "Likely legitimate", 1: "Potential fraud"}
        )

        total = len(results)
        flagged = int(predictions.sum())
        c1, c2, c3 = st.columns(3)
        c1.metric("Transactions scored", f"{total:,}")
        c2.metric("Flagged as potential fraud", f"{flagged:,}")
        c3.metric("Flag rate", f"{(flagged / total * 100 if total else 0):.2f}%")

        st.subheader("Predictions")
        st.dataframe(results.head(100), use_container_width=True)
        st.download_button(
            "Download all predictions as CSV",
            data=results.to_csv(index=False).encode("utf-8"),
            file_name="fraud_predictions.csv",
            mime="text/csv",
        )

        if "Class" in data.columns:
            st.subheader("Evaluation on uploaded labeled data")
            st.caption("Only use this section when Class labels are genuine ground truth and were not used to build the model.")
            y_true = pd.to_numeric(data["Class"], errors="coerce")
            if y_true.isna().any() or not set(y_true.unique()).issubset({0, 1}):
                st.warning("Class must contain only numeric 0/1 labels to calculate metrics.")
            else:
                y_true = y_true.astype(int)
                if y_true.nunique() < 2:
                    st.warning("Both classes (0 and 1) are needed for a meaningful evaluation.")
                else:
                    m1, m2, m3, m4 = st.columns(4)
                    m1.metric("Precision", f"{precision_score(y_true, predictions, zero_division=0):.3f}")
                    m2.metric("Recall", f"{recall_score(y_true, predictions, zero_division=0):.3f}")
                    m3.metric("F1-score", f"{f1_score(y_true, predictions, zero_division=0):.3f}")
                    m4.metric("PR-AUC / Average Precision", f"{average_precision_score(y_true, probabilities):.3f}")
                    st.write("Confusion matrix (rows = actual, columns = predicted; order 0, 1):")
                    st.dataframe(
                        pd.DataFrame(
                            confusion_matrix(y_true, predictions, labels=[0, 1]),
                            index=["Actual legitimate (0)", "Actual fraud (1)"],
                            columns=["Predicted legitimate (0)", "Predicted fraud (1)"],
                        ),
                        use_container_width=True,
                    )
    except Exception as exc:
        st.error(f"Could not process this file: {exc}")
else:
    st.info("No file uploaded yet. Start by uploading a small CSV with the required feature columns.")

st.divider()
st.caption("Privacy reminder: use public/sample data only. Do not upload real payment-card or customer data.")
