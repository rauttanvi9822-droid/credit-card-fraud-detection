# Credit Card Fraud Detection — Machine Learning + Streamlit

A beginner-friendly end-to-end ML project that predicts whether a credit-card transaction may be fraudulent.

## What this project does
- Loads the European credit-card fraud dataset from Kaggle.
- Explores the severe class imbalance (fraud is rare).
- Splits data into train, validation, and test sets using stratification.
- Trains Logistic Regression and Random Forest with class weights.
- Selects a model using **validation PR-AUC** and evaluates the chosen model on the test set only once.
- Reports precision, recall, F1-score, average precision (PR-AUC-style summary), and a confusion matrix.
- Offers a Streamlit app to score a CSV of transactions.

> **Important:** This is an educational project, not a production fraud-detection system. The dataset is anonymized and model predictions are not financial advice. Never upload real customers' sensitive payment data to a public demo.

## Dataset
Download **Credit Card Fraud Detection** from Kaggle:
https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud

After downloading and extracting, put `creditcard.csv` here:

```text
data/raw/creditcard.csv
```

The dataset should contain these columns: `Time`, `V1`–`V28`, `Amount`, and `Class`. `Class = 1` means fraud; `Class = 0` means legitimate.

The dataset is not included in this repository because it is large and has its own distribution terms.

## Project structure
```text
credit-card-fraud-detection/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── raw/                 # Put creditcard.csv here; not committed to Git
├── models/                  # Created after training; not committed to Git
├── reports/                 # Metrics and confusion matrix saved here
└── src/
    ├── __init__.py
    ├── data_utils.py
    └── train.py
```

## Run it in VS Code (Windows)

### 1. Install Python
Install a recent Python 3 version from https://www.python.org/downloads/ and select **Add Python to PATH** during installation. In VS Code, install the Microsoft **Python** extension.

### 2. Open this project
Extract the project ZIP, then in VS Code select **File → Open Folder** and choose `credit-card-fraud-detection`.

### 3. Open a terminal
Select **Terminal → New Terminal**.

### 4. Create a virtual environment
Run these commands one at a time in the VS Code terminal:

```powershell
python -m venv .venv
```

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt terminal instead and run:
```bat
.venv\Scripts\activate.bat
```

### 5. Install packages
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 6. Add the dataset
Create folders `data` and `data/raw` if they do not exist. Copy `creditcard.csv` into `data/raw/creditcard.csv`.

### 7. Train and evaluate
```powershell
python -m src.train
```

Training may take a few minutes, especially for Random Forest. The script prints the validation PR-AUC for each model, chooses the best validation model, then evaluates it on the held-out test set. It creates:
- `models/fraud_model.joblib`
- `reports/test_metrics.json`
- `reports/confusion_matrix.png`

**Do not copy made-up numbers into your README or LinkedIn post.** Use the metrics produced by your own run.

### 8. Launch the Streamlit app
```powershell
streamlit run app.py
```
Open the local URL shown in the terminal (usually `http://localhost:8501`).

In the app, upload a CSV containing the feature columns `Time`, `V1`–`V28`, and `Amount`. `Class` is optional. If included, it is used only to show evaluation metrics for that uploaded file; it is not used as a prediction input.

## How leakage is prevented
- The dataset is split **before** model fitting.
- Splits are stratified so the rare fraud class is represented in each split.
- Scaling for `Time` and `Amount` is inside a scikit-learn pipeline, so scaler parameters are learned from the training split only.
- `Class` is never used as an input feature.
- The test set is not used to choose the model; validation PR-AUC selects the model.

## Why accuracy is not enough
Fraud cases are rare. A model that predicts every transaction as legitimate can still get very high accuracy while catching no fraud. We therefore report:
- **Precision:** Of transactions flagged as fraud, how many really are fraud?
- **Recall:** Of actual fraud cases, how many did the model catch?
- **F1-score:** Balance between precision and recall.
- **PR-AUC / Average Precision:** Summarizes the precision-recall trade-off; especially useful for rare positive classes.

## GitHub checklist
Before pushing:
- Do not upload `creditcard.csv`, `.venv`, or generated model files.
- Run the project and capture your own screenshots.
- Replace the LinkedIn placeholders with your actual repository URL.
- Add your real metrics only after the training script finishes.

## LinkedIn post template
> 🚀 I built a Credit Card Fraud Detection ML project using Python, Pandas, Scikit-learn, and Streamlit.
>
> The project focuses on the challenges of highly imbalanced transaction data. I used stratified train/validation/test splits, a preprocessing pipeline to avoid data leakage, class-weighted models, and validation PR-AUC for model selection.
>
> I evaluated the selected model using precision, recall, F1-score, PR-AUC / average precision, and a confusion matrix. I also built a Streamlit app to score transaction CSV files.
>
> GitHub: [add your repository link]
>
> Metrics from my actual run: [add your measured results]
>
> #MachineLearning #Python #DataScience #FraudDetection #ScikitLearn #Streamlit
